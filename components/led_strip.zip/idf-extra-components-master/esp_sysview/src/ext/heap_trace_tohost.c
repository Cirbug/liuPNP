/*
 * SPDX-FileCopyrightText: 2015-2025 Espressif Systems (Shanghai) CO LTD
 *
 * SPDX-License-Identifier: Apache-2.0
 */
#include "sdkconfig.h"
#include "freertos/FreeRTOS.h"
#include "esp_heap_trace.h"
#include "esp_heap_caps.h"
#include "esp_sysview_heap_trace_module.h"

#define STACK_DEPTH CONFIG_HEAP_TRACING_STACK_DEPTH

static bool s_tracing;

esp_err_t heap_trace_init_tohost(void)
{
    if (s_tracing) {
        return ESP_ERR_INVALID_STATE;
    }
    return ESP_OK;
}

esp_err_t heap_trace_start(heap_trace_mode_t mode_param)
{
    esp_err_t ret = esp_sysview_heap_trace_start((uint32_t) -1);
    if (ret != ESP_OK) {
        return ret;
    }
    s_tracing = true;
    return ESP_OK;
}

esp_err_t heap_trace_stop(void)
{
    esp_err_t ret = esp_sysview_heap_trace_stop();
    s_tracing = false;
    return ret;
}

esp_err_t heap_trace_resume(void)
{
    return heap_trace_start(HEAP_TRACE_ALL);
}

size_t heap_trace_get_count(void)
{
    return 0;
}

esp_err_t heap_trace_get(size_t index, heap_trace_record_t *record)
{
    return ESP_ERR_NOT_SUPPORTED;
}

esp_err_t heap_trace_summary(heap_trace_summary_t *summary)
{
    return ESP_ERR_NOT_SUPPORTED;
}

void heap_trace_dump(void)
{
    return;
}

void heap_trace_dump_caps(__attribute__((unused)) const uint32_t caps)
{
    return;
}

/* Add a new allocation to the heap trace records */
static HEAP_IRAM_ATTR void record_allocation(const heap_trace_record_t *record)
{
    if (!s_tracing) {
        return;
    }
    esp_sysview_heap_trace_alloc(record->address, record->size, record->alloced_by);
}

/* record a free event in the heap trace log

   For HEAP_TRACE_ALL, this means filling in the freed_by pointer.
   For HEAP_TRACE_LEAKS, this means removing the record from the log.
*/
static HEAP_IRAM_ATTR void record_free(void *p, void **callers)
{
    if (!s_tracing) {
        return;
    }
    esp_sysview_heap_trace_free(p, callers);
}

#include "heap_trace.inc"
